import { useEffect, useState } from "react";
import { GAMES, getGame } from "./games/registry";
import { Home } from "./components/Home";
import { useProgress } from "./lib/progress";
import { shuffle } from "./lib/hooks";
import type { Result } from "./lib/types";
import { cn } from "./utils/cn";

type View =
  | { name: "home" }
  | { name: "intro"; id: string }
  | { name: "play"; id: string; run: number }
  | { name: "result"; id: string; result: Result; isBest: boolean; xpGain: number; prevBest: number };

function tier(pct: number) {
  if (pct >= 1) return { label: "Lightning Mind", emoji: "🏆" };
  if (pct >= 0.75) return { label: "Brilliant", emoji: "🌟" };
  if (pct >= 0.5) return { label: "Quick Thinker", emoji: "⚡" };
  if (pct >= 0.25) return { label: "Getting Sharp", emoji: "💪" };
  return { label: "Warming Up", emoji: "🌱" };
}

export default function App() {
  const { progress, record, reset } = useProgress();
  const [view, setView] = useState<View>({ name: "home" });
  const [queue, setQueue] = useState<string[]>([]);

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [view.name]);

  const goHome = () => {
    setQueue([]);
    setView({ name: "home" });
  };

  const startWorkout = () => {
    const [first, ...rest] = shuffle(GAMES.map((g) => g.id)).slice(0, 3);
    setQueue(rest);
    setView({ name: "intro", id: first });
  };

  const handleFinish = (id: string, result: Result) => {
    const g = getGame(id);
    const info = record(id, result.score, g.ref);
    setView({ name: "result", id, result, ...info });
  };

  return (
    <div className="bg-grid min-h-screen">
      {view.name === "home" && (
        <Home
          progress={progress}
          onPlay={(id) => {
            setQueue([]);
            setView({ name: "intro", id });
          }}
          onWorkout={startWorkout}
          onReset={reset}
        />
      )}

      {view.name === "intro" && (
        <Intro
          id={view.id}
          best={progress.best[view.id] ?? 0}
          queueLeft={queue.length}
          onBack={goHome}
          onStart={() => setView({ name: "play", id: view.id, run: Date.now() })}
        />
      )}

      {view.name === "play" && (
        <PlayScreen id={view.id} runKey={view.run} onExit={goHome} onFinish={(r) => handleFinish(view.id, r)} />
      )}

      {view.name === "result" && (
        <ResultScreen
          view={view}
          queue={queue}
          onAgain={() => setView({ name: "play", id: view.id, run: Date.now() })}
          onNext={() => {
            const [next, ...rest] = queue;
            setQueue(rest);
            setView({ name: "intro", id: next });
          }}
          onHome={goHome}
        />
      )}
    </div>
  );
}

function Intro({
  id,
  best,
  queueLeft,
  onBack,
  onStart,
}: {
  id: string;
  best: number;
  queueLeft: number;
  onBack: () => void;
  onStart: () => void;
}) {
  const g = getGame(id);
  useEffect(() => {
    const fn = (e: KeyboardEvent) => {
      if (e.key === "Enter") onStart();
      if (e.key === "Escape") onBack();
    };
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  });
  return (
    <div className="mx-auto flex min-h-screen w-full max-w-2xl flex-col justify-center px-4 py-10">
      <button onClick={onBack} className="mb-6 self-start text-sm font-semibold text-slate-400 transition hover:text-white">
        ← Back
      </button>
      <div className="anim-slide rounded-3xl border border-white/10 bg-white/[0.05] p-7 backdrop-blur sm:p-9">
        {queueLeft > 0 && (
          <div className="mb-4 inline-block rounded-full bg-violet-500/20 px-3 py-1 text-xs font-bold text-violet-200">
            Daily workout · {queueLeft} more after this
          </div>
        )}
        <div className="flex items-center gap-4">
          <div className={cn("flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br text-5xl shadow-xl", g.gradient)}>{g.emoji}</div>
          <div>
            <h1 className="text-3xl font-black text-white">{g.name}</h1>
            <div className={cn("text-xs font-bold uppercase tracking-widest", g.accent)}>Trains: {g.skill}</div>
          </div>
        </div>
        <p className="mt-5 text-slate-300">{g.why}</p>
        <h2 className="mb-2 mt-6 text-sm font-bold uppercase tracking-widest text-slate-400">How to play</h2>
        <ol className="space-y-2">
          {g.how.map((h, i) => (
            <li key={i} className="flex gap-3 text-sm text-slate-200">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-white/10 text-xs font-black">{i + 1}</span>
              <span className="pt-0.5">{h}</span>
            </li>
          ))}
        </ol>
        <div className="mt-6 flex items-center justify-between rounded-2xl bg-black/30 px-4 py-3 text-sm">
          <span className="text-slate-400">Duration: <b className="text-white">{g.duration}</b></span>
          <span className="text-slate-400">Your best: <b className="text-white">{best || "–"}</b></span>
        </div>
        <button
          onClick={onStart}
          className={cn("mt-6 w-full rounded-2xl bg-gradient-to-r py-4 text-lg font-black text-white shadow-xl transition hover:brightness-110 active:scale-[0.98]", g.gradient)}
        >
          Start <span className="ml-1 text-xs font-semibold opacity-75">(Enter)</span>
        </button>
      </div>
    </div>
  );
}

function PlayScreen({
  id,
  runKey,
  onExit,
  onFinish,
}: {
  id: string;
  runKey: number;
  onExit: () => void;
  onFinish: (r: Result) => void;
}) {
  const g = getGame(id);
  const [countdown, setCountdown] = useState(3);

  useEffect(() => {
    setCountdown(3);
    const t = setInterval(() => setCountdown((c) => c - 1), 750);
    return () => clearInterval(t);
  }, [runKey]);

  const G = g.Component;
  return (
    <div className="mx-auto flex min-h-screen w-full max-w-2xl flex-col px-4 py-6">
      <div className="mb-5 flex items-center justify-between">
        <button onClick={onExit} className="text-sm font-semibold text-slate-400 transition hover:text-white">
          ✕ Quit
        </button>
        <div className="flex items-center gap-2 text-sm font-bold text-white">
          <span>{g.emoji}</span> {g.name}
        </div>
        <div className="w-10" />
      </div>
      <div className="flex flex-1 items-start justify-center pt-2">
        {countdown > 0 ? (
          <div className="flex h-72 w-full flex-col items-center justify-center">
            <div key={countdown} className="anim-pop bg-gradient-to-br from-violet-400 to-cyan-300 bg-clip-text text-9xl font-black text-transparent">
              {countdown}
            </div>
            <div className="mt-2 text-sm font-semibold uppercase tracking-widest text-slate-400">Get ready</div>
          </div>
        ) : (
          <G key={runKey} onFinish={onFinish} />
        )}
      </div>
    </div>
  );
}

function ResultScreen({
  view,
  queue,
  onAgain,
  onNext,
  onHome,
}: {
  view: Extract<View, { name: "result" }>;
  queue: string[];
  onAgain: () => void;
  onNext: () => void;
  onHome: () => void;
}) {
  const g = getGame(view.id);
  const { result } = view;
  const pct = result.score / g.ref;
  const t = tier(pct);
  const [shown, setShown] = useState(0);

  useEffect(() => {
    const start = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / 900);
      setShown(Math.round(result.score * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [result.score]);

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-xl flex-col justify-center px-4 py-10">
      <div className="anim-pop rounded-3xl border border-white/10 bg-white/[0.05] p-7 text-center backdrop-blur sm:p-9">
        <div className="text-6xl">{t.emoji}</div>
        <div className={cn("mt-2 text-sm font-bold uppercase tracking-widest", g.accent)}>{g.name} · {t.label}</div>
        <div className="mt-3 text-7xl font-black tabular-nums text-white">{shown}</div>
        {view.isBest ? (
          <div className="mx-auto mt-2 inline-block rounded-full bg-amber-400/20 px-3 py-1 text-sm font-bold text-amber-300">
            🎉 New personal best{view.prevBest ? ` (was ${view.prevBest})` : "!"}
          </div>
        ) : (
          <div className="mt-2 text-sm text-slate-400">Personal best: {view.prevBest}</div>
        )}

        <div className="mt-6 grid grid-cols-2 gap-3 text-left">
          {result.details.map((d) => (
            <div key={d.label} className="rounded-2xl bg-black/30 px-4 py-3">
              <div className="text-[11px] font-semibold uppercase tracking-widest text-slate-500">{d.label}</div>
              <div className="text-lg font-extrabold text-white">{d.value}</div>
            </div>
          ))}
        </div>

        <div className="mt-4 rounded-2xl border border-violet-400/20 bg-violet-500/10 px-4 py-2.5 text-sm font-bold text-violet-200">
          +{view.xpGain} XP earned
        </div>

        <div className="mt-6 flex flex-col gap-3">
          {queue.length > 0 ? (
            <button onClick={onNext} className="rounded-2xl bg-gradient-to-r from-violet-600 to-cyan-500 py-4 text-lg font-black text-white shadow-xl transition hover:brightness-110 active:scale-[0.98]">
              Next: {getGame(queue[0]).emoji} {getGame(queue[0]).name} →
            </button>
          ) : (
            <button onClick={onAgain} className={cn("rounded-2xl bg-gradient-to-r py-4 text-lg font-black text-white shadow-xl transition hover:brightness-110 active:scale-[0.98]", g.gradient)}>
              Play again
            </button>
          )}
          {queue.length > 0 && (
            <button onClick={onAgain} className="rounded-2xl border border-white/15 bg-white/5 py-3 font-bold text-white transition hover:bg-white/10">
              Replay this game
            </button>
          )}
          <button onClick={onHome} className="py-2 text-sm font-semibold text-slate-400 transition hover:text-white">
            {queue.length > 0 ? "End workout" : "Back to all games"}
          </button>
        </div>
      </div>
    </div>
  );
}
