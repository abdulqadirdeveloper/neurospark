import { useCallback, useEffect, useReducer, useRef, useState } from "react";

/** Countdown timer in ms with the ability to add/subtract time (penalties). */
export function useCountdown(totalMs: number, onEnd: () => void) {
  const [left, setLeft] = useState(totalMs);
  const endAt = useRef(0);
  const ended = useRef(false);
  const cb = useRef(onEnd);
  cb.current = onEnd;

  useEffect(() => {
    endAt.current = Date.now() + totalMs;
    ended.current = false;
    setLeft(totalMs);
    const id = setInterval(() => {
      const l = Math.max(0, endAt.current - Date.now());
      setLeft(l);
      if (l <= 0 && !ended.current) {
        ended.current = true;
        clearInterval(id);
        cb.current();
      }
    }, 100);
    return () => clearInterval(id);
  }, [totalMs]);

  const adjust = useCallback((ms: number) => {
    endAt.current += ms;
  }, []);

  return { left, adjust };
}

/** Mutable stats object that triggers re-render on demand. */
export function useStats<T extends object>(initial: T) {
  const ref = useRef<T>(initial);
  const [, force] = useReducer((x: number) => x + 1, 0);
  const update = useCallback((fn: (s: T) => void) => {
    fn(ref.current);
    force();
  }, []);
  return [ref.current, update, ref] as const;
}

export function useKeys(handler: (key: string) => void) {
  const h = useRef(handler);
  h.current = handler;
  useEffect(() => {
    const fn = (e: KeyboardEvent) => {
      if (e.repeat) return;
      h.current(e.key);
    };
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, []);
}

export const rand = (a: number, b: number) => Math.floor(Math.random() * (b - a + 1)) + a;
export const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
