export type Result = {
  score: number;
  details: { label: string; value: string }[];
};

export type GameProps = {
  onFinish: (result: Result) => void;
};

export type Progress = {
  best: Record<string, number>;
  plays: Record<string, number>;
  history: { id: string; score: number; ts: number }[];
  xp: number;
  days: string[];
};
