import { useCallback, useEffect, useState } from "react";
import type { Progress } from "./types";

const KEY = "neurospark-progress-v1";

const empty: Progress = { best: {}, plays: {}, history: [], xp: 0, days: [] };

function load(): Progress {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return empty;
    return { ...empty, ...JSON.parse(raw) };
  } catch {
    return empty;
  }
}

const dayKey = (d = new Date()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

export function computeStreak(days: string[]): number {
  const set = new Set(days);
  const d = new Date();
  if (!set.has(dayKey(d))) d.setDate(d.getDate() - 1);
  let streak = 0;
  while (set.has(dayKey(d))) {
    streak++;
    d.setDate(d.getDate() - 1);
  }
  return streak;
}

export function levelFromXp(xp: number) {
  // Level n needs 120 * (n-1)^1.4 xp, roughly
  let level = 1;
  const need = (l: number) => Math.round(120 * Math.pow(l, 1.35));
  let floor = 0;
  while (xp >= floor + need(level)) {
    floor += need(level);
    level++;
  }
  const span = need(level);
  return { level, into: xp - floor, span };
}

export function useProgress() {
  const [progress, setProgress] = useState<Progress>(load);

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(progress));
    } catch {
      /* ignore */
    }
  }, [progress]);

  const record = useCallback(
    (id: string, score: number, ref: number) => {
      const prevBest = progress.best[id] ?? 0;
      const isBest = score > prevBest;
      const xpGain = Math.round(10 + Math.min(1.5, score / ref) * 60);
      const today = dayKey();
      setProgress((p) => ({
        best: { ...p.best, [id]: Math.max(p.best[id] ?? 0, score) },
        plays: { ...p.plays, [id]: (p.plays[id] ?? 0) + 1 },
        history: [...p.history, { id, score, ts: Date.now() }].slice(-60),
        xp: p.xp + xpGain,
        days: p.days.includes(today) ? p.days : [...p.days, today].slice(-90),
      }));
      return { isBest, xpGain, prevBest };
    },
    [progress.best],
  );

  const reset = useCallback(() => setProgress(empty), []);

  return { progress, record, reset };
}
