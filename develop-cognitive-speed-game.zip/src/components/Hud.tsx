import { cn } from "../utils/cn";

export function Hud({
  score,
  left,
  total,
  streak,
  label,
}: {
  score: number;
  left: number;
  total: number;
  streak?: number;
  label?: string;
}) {
  const pct = Math.max(0, Math.min(100, (left / total) * 100));
  const secs = Math.ceil(left / 1000);
  const low = secs <= 10;
  return (
    <div className="w-full">
      <div className="mb-3 flex items-end justify-between">
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-widest text-slate-400">Score</div>
          <div className="text-3xl font-black tabular-nums text-white">{score}</div>
        </div>
        {label && (
          <div className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-semibold text-slate-300">
            {label}
          </div>
        )}
        <div className="flex items-end gap-5">
          {typeof streak === "number" && (
            <div className="text-right">
              <div className="text-[11px] font-semibold uppercase tracking-widest text-slate-400">Streak</div>
              <div className={cn("text-2xl font-black tabular-nums", streak >= 5 ? "text-amber-400" : "text-white")}>
                {streak >= 5 ? "🔥" : ""}
                {streak}
              </div>
            </div>
          )}
          <div className="text-right">
            <div className="text-[11px] font-semibold uppercase tracking-widest text-slate-400">Time</div>
            <div className={cn("text-3xl font-black tabular-nums", low ? "text-rose-400" : "text-white")}>{secs}s</div>
          </div>
        </div>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
        <div
          className={cn(
            "h-full rounded-full transition-[width] duration-100 ease-linear",
            low ? "bg-rose-500" : "bg-gradient-to-r from-violet-500 to-cyan-400",
          )}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

export function Feedback({ fb }: { fb: { id: number; ok: boolean; text: string } | null }) {
  return (
    <div className="relative h-7 w-full text-center">
      {fb && (
        <span
          key={fb.id}
          className={cn("anim-float absolute left-0 right-0 text-lg font-extrabold", fb.ok ? "text-emerald-400" : "text-rose-400")}
        >
          {fb.text}
        </span>
      )}
    </div>
  );
}
