import type { Progress } from "../lib/types";
import { computeStreak, levelFromXp } from "../lib/progress";
import { GAMES } from "../games/registry";
import { Radar } from "./Radar";
import { Science } from "./Science";
import { cn } from "../utils/cn";

function skillPct(progress: Progress, id: string, ref: number) {
  return Math.min(1, (progress.best[id] ?? 0) / ref);
}

export function Home({
  progress,
  onPlay,
  onWorkout,
  onReset,
}: {
  progress: Progress;
  onPlay: (id: string) => void;
  onWorkout: () => void;
  onReset: () => void;
}) {
  const { level, into, span } = levelFromXp(progress.xp);
  const streak = computeStreak(progress.days);
  const values = GAMES.map((g) => skillPct(progress, g.id, g.ref));
  const mind = Math.round((values.reduce((a, b) => a + b, 0) / GAMES.length) * 100);
  const totalPlays = Object.values(progress.plays).reduce((a, b) => a + b, 0);
  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });

  return (
    <div className="mx-auto w-full max-w-6xl px-4 pb-20 sm:px-6">
      {/* Header */}
      <header className="flex items-center justify-between py-5">
        <div className="flex items-center gap-2.5">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 text-xl shadow-lg shadow-violet-900/50">⚡</div>
          <span className="text-xl font-black tracking-tight text-white">NeuroSpark</span>
        </div>
        <nav className="hidden items-center gap-6 text-sm font-semibold text-slate-400 sm:flex">
          <button onClick={() => scrollTo("games")} className="transition hover:text-white">Games</button>
          <button onClick={() => scrollTo("progress")} className="transition hover:text-white">Progress</button>
          <button onClick={() => scrollTo("science")} className="transition hover:text-white">The science</button>
        </nav>
      </header>

      {/* Hero */}
      <section className="grid items-center gap-8 pb-14 pt-6 lg:grid-cols-[1.2fr_1fr]">
        <div className="anim-slide">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-violet-400/30 bg-violet-500/10 px-3 py-1 text-xs font-bold uppercase tracking-widest text-violet-300">
            <span className="h-1.5 w-1.5 rounded-full bg-cyan-400" /> Research-based brain training
          </div>
          <h1 className="text-4xl font-black leading-[1.05] tracking-tight text-white sm:text-6xl">
            Think <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-300 bg-clip-text text-transparent">faster.</span>
            <br />
            Focus <span className="bg-gradient-to-r from-cyan-300 to-emerald-300 bg-clip-text text-transparent">sharper.</span>
          </h1>
          <p className="mt-5 max-w-xl text-lg leading-relaxed text-slate-300">
            Six fast games built on the cognitive skills science links to quick thinking: processing speed, working memory, focus control, and
            pattern reasoning. 15 minutes a day is all it takes.
          </p>
          <div className="mt-7 flex flex-wrap gap-3">
            <button
              onClick={onWorkout}
              className="anim-ring rounded-2xl bg-gradient-to-r from-violet-600 to-cyan-500 px-7 py-4 text-base font-black text-white shadow-xl shadow-violet-900/40 transition hover:brightness-110 active:scale-95"
            >
              ▶ Start daily workout <span className="ml-1 text-xs font-semibold opacity-80">(3 games)</span>
            </button>
            <button
              onClick={() => scrollTo("games")}
              className="rounded-2xl border border-white/15 bg-white/5 px-7 py-4 text-base font-bold text-white transition hover:bg-white/10"
            >
              Pick a game
            </button>
          </div>
          <div className="mt-8 flex flex-wrap gap-x-8 gap-y-3 text-sm text-slate-400">
            <span>⏱ 45–90 sec rounds</span>
            <span>📈 Adaptive difficulty</span>
            <span>💾 Progress saved on this device</span>
          </div>
        </div>

        {/* Status card */}
        <div id="progress" className="anim-slide rounded-3xl border border-white/10 bg-white/[0.04] p-6 backdrop-blur" style={{ animationDelay: "120ms" }}>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[11px] font-semibold uppercase tracking-widest text-slate-400">Your brain profile</div>
              <div className="mt-1 flex items-baseline gap-2">
                <span className="text-5xl font-black text-white">{totalPlays ? mind : "–"}</span>
                <span className="text-sm font-semibold text-slate-400">Mind Score</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-[11px] font-semibold uppercase tracking-widest text-slate-400">Streak</div>
              <div className="text-2xl font-black text-amber-300">🔥 {streak}<span className="text-sm text-slate-400"> day{streak === 1 ? "" : "s"}</span></div>
            </div>
          </div>
          <div className="mt-4">
            <div className="mb-1 flex justify-between text-xs font-semibold text-slate-400">
              <span>Level {level}</span>
              <span>{into} / {span} XP</span>
            </div>
            <div className="h-2.5 overflow-hidden rounded-full bg-white/10">
              <div className="h-full rounded-full bg-gradient-to-r from-violet-500 to-cyan-400 transition-all duration-500" style={{ width: `${(into / span) * 100}%` }} />
            </div>
          </div>
          <div className="mt-3">
            <Radar labels={GAMES.map((g) => g.short)} values={values} />
          </div>
          <p className="text-center text-xs text-slate-500">Mind Score is a training metric (your best score across all six skills) — not a clinical IQ.</p>
        </div>
      </section>

      {/* Games */}
      <section id="games" className="scroll-mt-6">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <h2 className="text-3xl font-black tracking-tight text-white">Train your skills</h2>
            <p className="mt-1 text-slate-400">Each game targets a different part of fast thinking.</p>
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {GAMES.map((g, i) => {
            const best = progress.best[g.id] ?? 0;
            const pct = Math.min(100, (best / g.ref) * 100);
            return (
              <button
                key={g.id}
                onClick={() => onPlay(g.id)}
                className="anim-slide group relative overflow-hidden rounded-3xl border border-white/10 bg-white/[0.04] p-5 text-left transition hover:-translate-y-1 hover:border-white/25 hover:bg-white/[0.07]"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                <div className={cn("absolute -right-10 -top-10 h-32 w-32 rounded-full bg-gradient-to-br opacity-20 blur-2xl transition group-hover:opacity-40", g.gradient)} />
                <div className="relative flex items-start justify-between">
                  <div className={cn("flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br text-3xl shadow-lg", g.gradient)}>{g.emoji}</div>
                  <span className="rounded-full bg-white/10 px-2.5 py-1 text-[11px] font-bold text-slate-300">{g.duration}</span>
                </div>
                <h3 className="relative mt-4 text-xl font-extrabold text-white">{g.name}</h3>
                <div className={cn("relative text-xs font-bold uppercase tracking-widest", g.accent)}>{g.skill}</div>
                <p className="relative mt-2 text-sm leading-relaxed text-slate-400">{g.tagline}</p>
                <div className="relative mt-4">
                  <div className="mb-1 flex justify-between text-xs font-semibold text-slate-400">
                    <span>Best: <b className="text-white">{best || "–"}</b></span>
                    <span>{progress.plays[g.id] ?? 0} plays</span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
                    <div className={cn("h-full rounded-full bg-gradient-to-r", g.gradient)} style={{ width: `${pct}%` }} />
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      <Science />

      <footer className="mt-16 flex flex-col items-center gap-3 border-t border-white/10 pt-8 text-center text-xs text-slate-500">
        <p>NeuroSpark is an educational training tool, not a medical device or a clinical IQ test.</p>
        {totalPlays > 0 && (
          <button
            onClick={() => {
              if (confirm("Reset all progress on this device?")) onReset();
            }}
            className="rounded-lg border border-white/10 px-3 py-1.5 font-semibold text-slate-400 transition hover:bg-white/5 hover:text-white"
          >
            Reset progress
          </button>
        )}
      </footer>
    </div>
  );
}
