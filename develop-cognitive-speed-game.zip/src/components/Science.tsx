import { cn } from "../utils/cn";

const FINDINGS = [
  {
    icon: "⚡",
    title: "Processing speed",
    games: "Speed Math · Schulte Table",
    evidence: "Strong",
    color: "bg-emerald-500/15 text-emerald-300 border-emerald-400/30",
    body: "In ACTIVE — the largest cognitive-training trial ever run (2,800+ adults) — speed-of-processing practice produced measurable gains that were still visible 10 years later, with participants reporting less difficulty in daily tasks.",
  },
  {
    icon: "🧠",
    title: "Working memory",
    games: "N-Back · Sequence Memory",
    evidence: "Moderate",
    color: "bg-amber-500/15 text-amber-300 border-amber-400/30",
    body: "N-back style training reliably improves the trained task and closely related memory tests. Early reports of big IQ jumps (Jaeggi 2008) were mixed in replications — so expect a sharper memory, not a magic IQ boost.",
  },
  {
    icon: "🎯",
    title: "Executive control",
    games: "Stroop Clash",
    evidence: "Promising",
    color: "bg-cyan-500/15 text-cyan-300 border-cyan-400/30",
    body: "A randomized trial gave young adults ~15 min/day of fast, varied mental tasks for 4 weeks. Versus a Tetris control, they improved in executive function, working memory and processing speed (Nouchi et al., 2013).",
  },
  {
    icon: "🧩",
    title: "Fluid reasoning",
    games: "Pattern Logic",
    evidence: "Mixed",
    color: "bg-fuchsia-500/15 text-fuchsia-300 border-fuchsia-400/30",
    body: "Spotting rules in novel patterns is what IQ-style tests measure. Practice makes you faster and better at this kind of problem — though how far that transfers to unrelated tasks is still debated.",
  },
];

const TIPS = [
  ["📅", "Little and often", "~15 minutes a day, 5 days a week is the dose used in successful trials. Consistency beats marathons."],
  ["🎯", "Stay at the edge", "Adaptive difficulty matters. If it feels easy, push the level — struggle is the training signal."],
  ["✅", "Accuracy first, then speed", "Fast guessing doesn't train anything. Be right, then get quicker. That's why mistakes cost you time here."],
  ["🔀", "Mix it up", "Rotate across speed, memory, focus and logic so you build broad skills instead of one narrow trick."],
  ["😴", "Sleep & move", "Sleep and aerobic exercise have some of the best evidence for sharper thinking. Pair them with training."],
  ["🧗", "Learn new things", "Languages, instruments and real problem-solving keep your brain stretching in ways games can't."],
];

export function Science() {
  return (
    <section id="science" className="mt-20 scroll-mt-6">
      <div className="mb-8 max-w-2xl">
        <div className="mb-2 text-xs font-bold uppercase tracking-widest text-cyan-300">Research behind the games</div>
        <h2 className="text-3xl font-black tracking-tight text-white">What actually makes you think faster?</h2>
        <p className="mt-2 text-slate-400">
          We reviewed trials on brain training, n-back, Stroop-type tasks and processing-speed practice, then built a game for each skill with
          the best evidence.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {FINDINGS.map((f) => (
          <div key={f.title} className="rounded-3xl border border-white/10 bg-white/[0.04] p-6">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/10 text-2xl">{f.icon}</span>
                <div>
                  <h3 className="text-lg font-extrabold text-white">{f.title}</h3>
                  <div className="text-xs font-semibold text-slate-400">{f.games}</div>
                </div>
              </div>
              <span className={cn("shrink-0 rounded-full border px-3 py-1 text-xs font-bold", f.color)}>{f.evidence}</span>
            </div>
            <p className="mt-4 text-sm leading-relaxed text-slate-300">{f.body}</p>
          </div>
        ))}
      </div>

      <div className="mt-4 rounded-3xl border border-amber-400/25 bg-amber-400/[0.06] p-6">
        <h3 className="flex items-center gap-2 text-lg font-extrabold text-amber-200">⚠️ The honest bottom line</h3>
        <p className="mt-2 text-sm leading-relaxed text-slate-300">
          Brain training reliably improves the skills you practise (“near transfer”). Evidence that it raises general IQ or transfers to
          unrelated abilities (“far transfer”) is weak and debated — several large studies and meta-analyses found little broad effect. Treat
          these games as a workout for speed, focus and memory, not an IQ pill.
        </p>
      </div>

      <h3 className="mb-4 mt-12 text-2xl font-black text-white">6 habits for faster thinking</h3>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {TIPS.map(([icon, title, body]) => (
          <div key={title} className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
            <div className="text-2xl">{icon}</div>
            <div className="mt-2 font-extrabold text-white">{title}</div>
            <p className="mt-1 text-sm leading-relaxed text-slate-400">{body}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 text-xs leading-relaxed text-slate-500">
        Sources:{" "}
        <a className="underline hover:text-slate-300" target="_blank" rel="noreferrer" href="https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0055518">
          Nouchi et al. 2013, PLoS ONE
        </a>
        {" · "}
        <a className="underline hover:text-slate-300" target="_blank" rel="noreferrer" href="https://gwern.net/dnb-faq">
          Dual n-back research overview
        </a>
        {" · "}
        <a className="underline hover:text-slate-300" target="_blank" rel="noreferrer" href="https://www.researchgate.net/publication/299650932_Dual_N-Back_Working_Memory_Training_in_Healthy_Adults_A_Randomized_Comparison_to_Processing_Speed_Training">
          Lawlor-Savage &amp; Goghari 2016
        </a>
        {" · "}
        <a className="underline hover:text-slate-300" target="_blank" rel="noreferrer" href="https://playbrain.games/blog/do-brain-games-work-science-research">
          ACTIVE trial summary
        </a>
      </div>
    </section>
  );
}
