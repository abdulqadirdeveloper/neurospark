export function Radar({ labels, values }: { labels: string[]; values: number[] }) {
  const size = 260;
  const c = size / 2;
  const r = 90;
  const n = labels.length;
  const pt = (i: number, v: number) => {
    const a = (Math.PI * 2 * i) / n - Math.PI / 2;
    return [c + Math.cos(a) * r * v, c + Math.sin(a) * r * v] as const;
  };
  const poly = (v: number[]) => v.map((x, i) => pt(i, x).join(",")).join(" ");
  const rings = [0.25, 0.5, 0.75, 1];
  return (
    <svg viewBox={`0 0 ${size} ${size}`} className="mx-auto w-full max-w-[280px]">
      <defs>
        <linearGradient id="radarFill" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.65" />
          <stop offset="100%" stopColor="#22d3ee" stopOpacity="0.55" />
        </linearGradient>
      </defs>
      {rings.map((k) => (
        <polygon key={k} points={poly(labels.map(() => k))} fill="none" stroke="rgba(255,255,255,0.1)" />
      ))}
      {labels.map((_, i) => {
        const [x, y] = pt(i, 1);
        return <line key={i} x1={c} y1={c} x2={x} y2={y} stroke="rgba(255,255,255,0.08)" />;
      })}
      <polygon points={poly(values.map((v) => Math.max(0.04, v)))} fill="url(#radarFill)" stroke="#a78bfa" strokeWidth={2} />
      {values.map((v, i) => {
        const [x, y] = pt(i, Math.max(0.04, v));
        return <circle key={i} cx={x} cy={y} r={3.5} fill="#22d3ee" />;
      })}
      {labels.map((l, i) => {
        const [x, y] = pt(i, 1.24);
        return (
          <text key={l} x={x} y={y} fill="#94a3b8" fontSize="11" fontWeight={600} textAnchor="middle" dominantBaseline="middle">
            {l}
          </text>
        );
      })}
    </svg>
  );
}
