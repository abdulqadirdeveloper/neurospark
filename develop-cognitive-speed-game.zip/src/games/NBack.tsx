import { useEffect, useRef, useState } from "react";
import type { GameProps } from "../lib/types";
import { useKeys, useStats, rand } from "../lib/hooks";
import { cn } from "../utils/cn";

const SHOW_MS = 800;
const TRIAL_MS = 2300;

function makeSeq(n: number, length: number) {
  const seq: number[] = [];
  const match: boolean[] = [];
  for (let i = 0; i < length; i++) {
    if (i >= n && Math.random() < 0.32) {
      seq.push(seq[i - n]);
      match.push(true);
    } else {
      let c = rand(0, 8);
      while (i >= n && c === seq[i - n]) c = rand(0, 8);
      seq.push(c);
      match.push(false);
    }
  }
  return { seq, match };
}

export default function NBack({ onFinish }: GameProps) {
  const [n, setN] = useState<number | null>(null);
  const [data, setData] = useState<{ seq: number[]; match: boolean[] } | null>(null);
  const [idx, setIdx] = useState(0);
  const [lit, setLit] = useState(false);
  const [fb, setFb] = useState<{ id: number; ok: boolean; text: string } | null>(null);
  const [s, update, sRef] = useStats({ hits: 0, miss: 0, rej: 0, fa: 0 });
  const responded = useRef(false);
  const finished = useRef(false);

  const total = n ? 20 + n : 0;

  const start = (level: number) => {
    setN(level);
    setData(makeSeq(level, 20 + level));
    setIdx(0);
  };

  const finish = () => {
    if (finished.current || !n) return;
    finished.current = true;
    const st = sRef.current;
    const score = Math.max(0, (st.hits * 10 + st.rej * 2 - st.fa * 6) * n);
    const matches = st.hits + st.miss;
    onFinish({
      score,
      details: [
        { label: "N-back level", value: `${n}-back` },
        { label: "Matches caught", value: `${st.hits}/${matches}` },
        { label: "False alarms", value: String(st.fa) },
        { label: "Accuracy", value: `${Math.round(((st.hits + st.rej) / total) * 100)}%` },
      ],
    });
  };

  useEffect(() => {
    if (!data || !n) return;
    responded.current = false;
    setLit(true);
    const t1 = setTimeout(() => setLit(false), SHOW_MS);
    const t2 = setTimeout(() => {
      if (!responded.current) {
        if (data.match[idx]) {
          update((st) => { st.miss += 1; });
          setFb({ id: Date.now(), ok: false, text: "Missed match" });
        } else {
          update((st) => { st.rej += 1; });
        }
      }
      if (idx + 1 >= data.seq.length) finish();
      else setIdx(idx + 1);
    }, TRIAL_MS);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, idx]);

  const press = () => {
    if (!data || responded.current || finished.current) return;
    responded.current = true;
    if (data.match[idx]) {
      update((st) => { st.hits += 1; });
      setFb({ id: Date.now(), ok: true, text: "Match! +10" });
    } else {
      update((st) => { st.fa += 1; });
      setFb({ id: Date.now(), ok: false, text: "No match here" });
    }
  };

  useKeys((k) => {
    if (k === " " || k === "Enter") press();
  });

  if (!n || !data) {
    return (
      <div className="mx-auto flex w-full max-w-xl flex-col items-center gap-6 text-center">
        <h3 className="text-2xl font-extrabold text-white">Choose your N</h3>
        <p className="text-slate-400">
          A square lights up every ~2 seconds. Press <b className="text-white">MATCH</b> when the current square is in the
          same spot as it was <b className="text-white">N steps ago</b>.
        </p>
        <div className="grid w-full grid-cols-3 gap-3">
          {[
            { v: 1, t: "Warm-up", d: "Compare with the last one" },
            { v: 2, t: "Classic", d: "Two steps back" },
            { v: 3, t: "Hard", d: "Three steps back" },
          ].map((o) => (
            <button
              key={o.v}
              onClick={() => start(o.v)}
              className="rounded-2xl border border-white/10 bg-white/5 p-4 transition hover:border-violet-400/60 hover:bg-violet-500/20 active:scale-95"
            >
              <div className="text-4xl font-black text-white">{o.v}</div>
              <div className="text-sm font-bold text-violet-300">{o.t}</div>
              <div className="mt-1 text-xs text-slate-400">{o.d}</div>
            </button>
          ))}
        </div>
        <p className="text-xs text-slate-500">Higher N multiplies your score.</p>
      </div>
    );
  }

  const current = data.seq[idx];
  const score = Math.max(0, (s.hits * 10 + s.rej * 2 - s.fa * 6) * n);

  return (
    <div className="mx-auto flex w-full max-w-md flex-col items-center gap-5 no-select">
      <div className="flex w-full items-end justify-between">
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-widest text-slate-400">Score</div>
          <div className="text-3xl font-black tabular-nums text-white">{score}</div>
        </div>
        <div className="rounded-full border border-violet-400/40 bg-violet-500/15 px-4 py-1 text-sm font-bold text-violet-200">{n}-back</div>
        <div className="text-right">
          <div className="text-[11px] font-semibold uppercase tracking-widest text-slate-400">Trial</div>
          <div className="text-3xl font-black tabular-nums text-white">
            {idx + 1}<span className="text-lg text-slate-500">/{total}</span>
          </div>
        </div>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
        <div className="h-full rounded-full bg-gradient-to-r from-violet-500 to-cyan-400 transition-all duration-300" style={{ width: `${(idx / total) * 100}%` }} />
      </div>

      <div className="relative h-7 w-full text-center">
        {fb && (
          <span key={fb.id} className={cn("anim-float absolute left-0 right-0 text-lg font-extrabold", fb.ok ? "text-emerald-400" : "text-rose-400")}>
            {fb.text}
          </span>
        )}
      </div>

      <div className="grid w-full grid-cols-3 gap-3 rounded-3xl border border-white/10 bg-black/30 p-4">
        {Array.from({ length: 9 }, (_, i) => (
          <div
            key={i}
            className={cn(
              "aspect-square rounded-2xl border transition-all duration-150",
              lit && current === i
                ? "scale-100 border-cyan-300 bg-gradient-to-br from-cyan-400 to-violet-500 shadow-[0_0_30px_rgba(34,211,238,0.6)]"
                : "scale-95 border-white/5 bg-white/5",
            )}
          />
        ))}
      </div>

      <button
        onClick={press}
        className="w-full rounded-2xl bg-gradient-to-r from-violet-600 to-cyan-500 py-5 text-xl font-black tracking-wide text-white shadow-lg shadow-violet-900/40 transition active:scale-95"
      >
        MATCH <span className="ml-2 text-xs font-semibold opacity-70">(space)</span>
      </button>
      <p className="text-xs text-slate-500">Same position as {n} step{n > 1 ? "s" : ""} ago? Press MATCH. Otherwise, do nothing.</p>
    </div>
  );
}
