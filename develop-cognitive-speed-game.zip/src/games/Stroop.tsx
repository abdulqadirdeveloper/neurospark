import { useRef, useState } from "react";
import type { GameProps } from "../lib/types";
import { Feedback, Hud } from "../components/Hud";
import { useCountdown, useKeys, useStats, pick, shuffle } from "../lib/hooks";

const TOTAL = 45_000;
const BLOCK = 5;

const COLORS = [
  { name: "RED", hex: "#ef4444" },
  { name: "BLUE", hex: "#3b82f6" },
  { name: "GREEN", hex: "#22c55e" },
  { name: "YELLOW", hex: "#facc15" },
  { name: "PURPLE", hex: "#c084fc" },
  { name: "ORANGE", hex: "#fb923c" },
];

type Trial = { word: string; ink: string };

function makeTrial(count: number): Trial {
  const pool = COLORS.slice(0, count);
  const word = pick(pool);
  const incongruent = Math.random() < 0.85;
  const ink = incongruent ? pick(pool.filter((c) => c.name !== word.name)) : word;
  return { word: word.name, ink: ink.name };
}

export default function Stroop({ onFinish }: GameProps) {
  const [s, update, sRef] = useStats({ score: 0, correct: 0, wrong: 0, streak: 0, bestStreak: 0, trials: 0, rtSum: 0 });
  const [trial, setTrial] = useState<Trial>(() => makeTrial(4));
  const [fb, setFb] = useState<{ id: number; ok: boolean; text: string } | null>(null);
  const [shake, setShake] = useState(0);
  const startedAt = useRef(Date.now());
  const done = useRef(false);

  const colorCount = s.correct >= 12 ? 6 : 4;
  const block = Math.floor(s.trials / BLOCK);
  const rule: "ink" | "word" = block % 2 === 0 ? "ink" : "word";
  const justSwitched = s.trials % BLOCK === 0 && s.trials > 0;

  const { left, adjust } = useCountdown(TOTAL, () => {
    if (done.current) return;
    done.current = true;
    const st = sRef.current;
    const total = st.correct + st.wrong;
    onFinish({
      score: st.score,
      details: [
        { label: "Correct", value: String(st.correct) },
        { label: "Accuracy", value: total ? `${Math.round((st.correct / total) * 100)}%` : "–" },
        { label: "Avg reaction", value: st.trials ? `${(st.rtSum / st.trials / 1000).toFixed(2)}s` : "–" },
        { label: "Best streak", value: String(st.bestStreak) },
      ],
    });
  });

  const answer = (name: string) => {
    if (done.current) return;
    const rt = Date.now() - startedAt.current;
    const target = rule === "ink" ? trial.ink : trial.word;
    const ok = name === target;
    if (ok) {
      const bonus = Math.max(0, Math.round((1500 - rt) / 150));
      const gain = 10 + bonus + Math.min(sRef.current.streak, 8);
      update((st) => {
        st.score += gain;
        st.correct += 1;
        st.streak += 1;
        st.bestStreak = Math.max(st.bestStreak, st.streak);
        st.trials += 1;
        st.rtSum += rt;
      });
      setFb({ id: Date.now(), ok: true, text: `+${gain}` });
    } else {
      adjust(-2000);
      update((st) => {
        st.score = Math.max(0, st.score - 5);
        st.wrong += 1;
        st.streak = 0;
        st.trials += 1;
        st.rtSum += rt;
      });
      setFb({ id: Date.now(), ok: false, text: "−5  −2s" });
      setShake((n) => n + 1);
    }
    const nextCount = sRef.current.correct >= 12 ? 6 : 4;
    setTrial(makeTrial(nextCount));
    startedAt.current = Date.now();
  };

  const buttons = shuffle(COLORS.slice(0, colorCount).map((c) => c.name));
  // stable order within a trial: derive from trial identity
  const order = useRef<{ key: string; list: string[] }>({ key: "", list: [] });
  const key = `${s.trials}-${colorCount}`;
  if (order.current.key !== key) order.current = { key, list: buttons };

  useKeys((k) => {
    const i = Number(k) - 1;
    if (i >= 0 && i < order.current.list.length) answer(order.current.list[i]);
  });

  const inkHex = COLORS.find((c) => c.name === trial.ink)!.hex;

  return (
    <div className="mx-auto flex w-full max-w-xl flex-col items-center gap-5 no-select">
      <Hud score={s.score} left={left} total={TOTAL} streak={s.streak} label={`${colorCount} colours`} />
      <Feedback fb={fb} />

      <div
        key={`rule-${block}`}
        className={`anim-pop w-full rounded-2xl border px-4 py-3 text-center text-sm font-bold uppercase tracking-widest ${
          rule === "ink"
            ? "border-cyan-400/40 bg-cyan-400/10 text-cyan-300"
            : "border-fuchsia-400/40 bg-fuchsia-400/10 text-fuchsia-300"
        }`}
      >
        {justSwitched && <span className="mr-2">🔀 Rule switch!</span>}
        {rule === "ink" ? "Tap the colour of the INK" : "Tap what the WORD says"}
      </div>

      <div
        key={`shake-${shake}`}
        className={`flex h-44 w-full items-center justify-center rounded-3xl border border-white/10 bg-black/30 ${shake ? "anim-shake" : ""}`}
      >
        <div key={s.trials} className="anim-pop text-6xl font-black tracking-wider sm:text-7xl" style={{ color: inkHex }}>
          {trial.word}
        </div>
      </div>

      <div className={`grid w-full gap-3 ${colorCount === 6 ? "grid-cols-3" : "grid-cols-2"}`}>
        {order.current.list.map((name, i) => (
          <button
            key={name}
            onClick={() => answer(name)}
            className="relative rounded-2xl border border-white/10 bg-white/5 py-4 text-lg font-extrabold tracking-wider text-white transition hover:border-white/40 hover:bg-white/10 active:scale-95"
          >
            <span className="absolute left-3 top-1.5 text-[10px] font-semibold text-slate-500">{i + 1}</span>
            {name}
          </button>
        ))}
      </div>
      <p className="text-xs text-slate-500">The rule flips every {BLOCK} answers — stay flexible. Wrong answers cost 2 seconds.</p>
    </div>
  );
}
