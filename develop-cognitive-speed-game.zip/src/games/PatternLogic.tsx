import { useRef, useState } from "react";
import type { GameProps } from "../lib/types";
import { Feedback, Hud } from "../components/Hud";
import { useCountdown, useKeys, useStats, rand, pick, shuffle } from "../lib/hooks";

const TOTAL = 90_000;

type Item = number | string;
type Puzzle = { seq: Item[]; answer: Item; options: Item[]; level: number; rule: string };

const A = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

function build(level: number): { terms: Item[]; rule: string } {
  const gens: Record<number, (() => { terms: Item[]; rule: string })[]> = {
    1: [
      () => { const d = rand(2, 9), s = rand(1, 20); return { terms: Array.from({ length: 6 }, (_, i) => s + d * i), rule: `+${d} each step` }; },
      () => { const d = rand(2, 7), s = rand(40, 80); return { terms: Array.from({ length: 6 }, (_, i) => s - d * i), rule: `−${d} each step` }; },
    ],
    2: [
      () => { const m = pick([2, 3]), s = rand(1, 4); return { terms: Array.from({ length: 5 }, (_, i) => s * Math.pow(m, i)), rule: `×${m} each step` }; },
      () => {
        const a = rand(3, 9), b = rand(1, a - 1), s = rand(5, 20);
        const t = [s];
        for (let i = 1; i < 7; i++) t.push(t[i - 1] + (i % 2 ? a : -b));
        return { terms: t, rule: `alternating +${a}, −${b}` };
      },
    ],
    3: [
      () => { const k = rand(0, 5), st = rand(1, 3); return { terms: Array.from({ length: 6 }, (_, i) => (i + st) ** 2 + k), rule: `squares${k ? ` + ${k}` : ""}` }; },
      () => { const d = rand(1, 3), s = rand(1, 10); const t = [s]; for (let i = 1; i < 7; i++) t.push(t[i - 1] + d * i); return { terms: t, rule: `growing gaps (+${d}, +${2 * d}, +${3 * d}…)` }; },
    ],
    4: [
      () => { const a = rand(1, 4), b = rand(2, 6); const t = [a, b]; for (let i = 2; i < 7; i++) t.push(t[i - 1] + t[i - 2]); return { terms: t, rule: "each term = sum of previous two" }; },
      () => {
        const a = rand(2, 9), x = rand(2, 5), b = rand(20, 50), y = rand(3, 9);
        const t: number[] = [];
        for (let i = 0; i < 4; i++) { t.push(a + x * i); t.push(b + y * i); }
        return { terms: t.slice(0, 7), rule: "two interleaved sequences" };
      },
    ],
    5: [
      () => { const m = pick([2, 3]), c = pick([-1, 1, 2]), s = rand(1, 4); const t = [s]; for (let i = 1; i < 6; i++) t.push(t[i - 1] * m + c); return { terms: t, rule: `×${m} then ${c > 0 ? "+" : "−"}${Math.abs(c)}` }; },
      () => { const k = rand(1, 3), st = rand(1, 3); return { terms: Array.from({ length: 6 }, (_, i) => (i + st) ** 3 + k), rule: "cubes" }; },
    ],
    6: [
      () => {
        const d = rand(2, 4), s = rand(0, 5);
        return { terms: Array.from({ length: 6 }, (_, i) => A[(s + d * i) % 26]), rule: `letters skip ${d - 1}` };
      },
      () => {
        const d = rand(1, 3), s = rand(0, 4);
        const t: Item[] = [];
        for (let i = 0; i < 4; i++) { t.push(A[s + i * (d + 1)]); t.push((i + 1) * (d + 2)); }
        return { terms: t.slice(0, 7), rule: "letters and numbers interleaved" };
      },
    ],
  };
  return pick(gens[level])();
}

function makePuzzle(level: number): Puzzle {
  const { terms, rule } = build(level);
  const answer = terms[terms.length - 1];
  const seq = terms.slice(0, -1);
  const opts = new Set<Item>([answer]);
  if (typeof answer === "number") {
    const prev = seq[seq.length - 1] as number;
    const prev2 = seq[seq.length - 2];
    if (typeof prev2 === "number") opts.add(prev + (prev - prev2));
    for (const o of shuffle([1, -1, 2, -2, 3, -3, 4, 5, -5, 10, -10])) {
      if (opts.size >= 4) break;
      opts.add(answer + o);
    }
  } else {
    const idx = A.indexOf(answer);
    for (const o of shuffle([1, -1, 2, -2, 3, -3, 4])) {
      if (opts.size >= 4) break;
      const j = idx + o;
      if (j >= 0 && j < 26) opts.add(A[j]);
    }
  }
  // distractor for mixed puzzle where answer is a number but options were derived above
  while (opts.size < 4) opts.add(rand(1, 99));
  return { seq, answer, options: shuffle([...opts]), level, rule };
}

export default function PatternLogic({ onFinish }: GameProps) {
  const [s, update, sRef] = useStats({ score: 0, correct: 0, wrong: 0, streak: 0, bestStreak: 0, maxLevel: 1 });
  const [p, setP] = useState<Puzzle>(() => makePuzzle(1));
  const [fb, setFb] = useState<{ id: number; ok: boolean; text: string } | null>(null);
  const [reveal, setReveal] = useState<string | null>(null);
  const [shake, setShake] = useState(0);
  const startedAt = useRef(Date.now());
  const done = useRef(false);

  const { left, adjust } = useCountdown(TOTAL, () => {
    if (done.current) return;
    done.current = true;
    const st = sRef.current;
    const total = st.correct + st.wrong;
    onFinish({
      score: st.score,
      details: [
        { label: "Solved", value: String(st.correct) },
        { label: "Accuracy", value: total ? `${Math.round((st.correct / total) * 100)}%` : "–" },
        { label: "Highest level", value: String(st.maxLevel) },
        { label: "Best streak", value: String(st.bestStreak) },
      ],
    });
  });

  const answer = (v: Item) => {
    if (done.current) return;
    const rt = Date.now() - startedAt.current;
    if (v === p.answer) {
      const bonus = rt < 6000 ? 5 : 0;
      const gain = 10 + p.level * 2 + bonus;
      update((st) => {
        st.score += gain;
        st.correct += 1;
        st.streak += 1;
        st.bestStreak = Math.max(st.bestStreak, st.streak);
      });
      setFb({ id: Date.now(), ok: true, text: `+${gain}${bonus ? " ⚡" : ""}` });
      setReveal(null);
      const level = Math.min(6, 1 + Math.floor(sRef.current.correct / 3));
      update((st) => { st.maxLevel = Math.max(st.maxLevel, level); });
      setP(makePuzzle(level));
    } else {
      adjust(-4000);
      update((st) => {
        st.wrong += 1;
        st.streak = 0;
      });
      setFb({ id: Date.now(), ok: false, text: "−4s" });
      setReveal(`Answer was ${p.answer} — rule: ${p.rule}`);
      setShake((n) => n + 1);
      setP(makePuzzle(p.level));
    }
    startedAt.current = Date.now();
  };

  useKeys((k) => {
    const i = Number(k) - 1;
    if (i >= 0 && i < 4) answer(p.options[i]);
  });

  return (
    <div className="mx-auto flex w-full max-w-xl flex-col items-center gap-5 no-select">
      <Hud score={s.score} left={left} total={TOTAL} streak={s.streak} label={`Level ${p.level}`} />
      <Feedback fb={fb} />
      <div
        key={shake}
        className={`flex min-h-40 w-full flex-wrap items-center justify-center gap-2 rounded-3xl border border-white/10 bg-gradient-to-br from-emerald-500/10 to-cyan-500/10 p-4 ${shake ? "anim-shake" : ""}`}
      >
        {p.seq.map((t, i) => (
          <div
            key={`${s.correct}-${s.wrong}-${i}`}
            className="anim-pop flex h-14 min-w-14 items-center justify-center rounded-xl bg-white/10 px-2 text-2xl font-black text-white sm:h-16 sm:min-w-16 sm:text-3xl"
            style={{ animationDelay: `${i * 40}ms` }}
          >
            {t}
          </div>
        ))}
        <div className="flex h-14 min-w-14 items-center justify-center rounded-xl border-2 border-dashed border-cyan-400 px-2 text-2xl font-black text-cyan-300 sm:h-16 sm:min-w-16 sm:text-3xl">
          ?
        </div>
      </div>
      <div className="grid w-full grid-cols-2 gap-3">
        {p.options.map((o, i) => (
          <button
            key={`${s.correct}-${s.wrong}-${o}`}
            onClick={() => answer(o)}
            className="group relative rounded-2xl border border-white/10 bg-white/5 py-5 text-3xl font-extrabold text-white transition hover:border-emerald-400/60 hover:bg-emerald-500/20 active:scale-95"
          >
            <span className="absolute left-3 top-2 text-[11px] font-semibold text-slate-500 group-hover:text-emerald-300">{i + 1}</span>
            {o}
          </button>
        ))}
      </div>
      <p className="min-h-4 text-center text-xs text-amber-300/80">{reveal ?? "Find the rule, then pick what comes next. Wrong answers cost 4 seconds."}</p>
    </div>
  );
}
