import { useRef, useState } from "react";
import type { GameProps } from "../lib/types";
import { Feedback, Hud } from "../components/Hud";
import { useCountdown, useKeys, useStats, rand, pick, shuffle } from "../lib/hooks";

const TOTAL = 60_000;

type Q = { text: string; options: number[]; answer: number; level: number };

function makeQ(level: number): Q {
  let text = "";
  let answer = 0;
  const gens: Record<number, (() => void)[]> = {
    1: [
      () => { const a = rand(3, 20), b = rand(2, 15); text = `${a} + ${b}`; answer = a + b; },
      () => { const a = rand(10, 30), b = rand(2, 9); text = `${a} − ${b}`; answer = a - b; },
    ],
    2: [
      () => { const a = rand(12, 89), b = rand(11, 59); text = `${a} + ${b}`; answer = a + b; },
      () => { const a = rand(50, 99), b = rand(12, 49); text = `${a} − ${b}`; answer = a - b; },
    ],
    3: [
      () => { const a = rand(3, 9), b = rand(3, 12); text = `${a} × ${b}`; answer = a * b; },
      () => { const b = rand(3, 9), q = rand(3, 12); text = `${b * q} ÷ ${b}`; answer = q; },
    ],
    4: [
      () => { const a = rand(11, 19), b = rand(3, 9); text = `${a} × ${b}`; answer = a * b; },
      () => { const a = rand(10, 40), b = rand(10, 40), c = rand(5, 30); text = `${a} + ${b} − ${c}`; answer = a + b - c; },
    ],
    5: [
      () => { const a = rand(3, 12), b = rand(3, 9), c = rand(2, 9); text = `(${a} + ${b}) × ${c}`; answer = (a + b) * c; },
      () => { const a = rand(6, 15), b = rand(4, 12), c = rand(5, 40); text = `${a} × ${b} − ${c}`; answer = a * b - c; },
    ],
    6: [
      () => { const a = rand(12, 25), b = rand(6, 15); text = `${a} × ${b}`; answer = a * b; },
      () => { const a = rand(4, 12), b = rand(4, 12), c = rand(3, 9); text = `${a} × ${b} + ${c} × ${rand(2, 6)}`; answer = NaN; /* replaced below */ },
    ],
  };
  const fn = pick(gens[level]);
  fn();
  if (Number.isNaN(answer)) {
    const a = rand(4, 12), b = rand(4, 12), c = rand(3, 9), d = rand(2, 6);
    text = `${a} × ${b} + ${c} × ${d}`;
    answer = a * b + c * d;
  }
  const offsets = shuffle([1, -1, 2, -2, 3, -3, 10, -10, 5, -5, 4, -4]);
  const opts = new Set<number>([answer]);
  for (const o of offsets) {
    if (opts.size >= 4) break;
    const v = answer + o;
    if (v >= 0) opts.add(v);
  }
  return { text, answer, options: shuffle([...opts]), level };
}

export default function SpeedMath({ onFinish }: GameProps) {
  const [s, update, sRef] = useStats({ score: 0, correct: 0, wrong: 0, streak: 0, bestStreak: 0 });
  const [q, setQ] = useState<Q>(() => makeQ(1));
  const [fb, setFb] = useState<{ id: number; ok: boolean; text: string } | null>(null);
  const [shake, setShake] = useState(0);
  const startedAt = useRef(Date.now());
  const done = useRef(false);

  const { left, adjust } = useCountdown(TOTAL, () => {
    if (done.current) return;
    done.current = true;
    const st = sRef.current;
    const total = st.correct + st.wrong;
    onFinish({
      score: st.score,
      details: [
        { label: "Correct", value: String(st.correct) },
        { label: "Accuracy", value: total ? `${Math.round((st.correct / total) * 100)}%` : "–" },
        { label: "Best streak", value: String(st.bestStreak) },
        { label: "Speed", value: total ? `${(TOTAL / 1000 / total).toFixed(1)}s / answer` : "–" },
      ],
    });
  });

  const answer = (v: number) => {
    if (done.current) return;
    const rt = Date.now() - startedAt.current;
    const ok = v === q.answer;
    if (ok) {
      const bonus = rt < 2000 ? 5 : 0;
      const gain = 10 + Math.min(sRef.current.streak, 10) * 2 + bonus;
      update((st) => {
        st.score += gain;
        st.correct += 1;
        st.streak += 1;
        st.bestStreak = Math.max(st.bestStreak, st.streak);
      });
      setFb({ id: Date.now(), ok: true, text: `+${gain}${bonus ? " ⚡" : ""}` });
      const level = Math.min(6, 1 + Math.floor(sRef.current.correct / 4));
      setQ(makeQ(level));
    } else {
      adjust(-3000);
      update((st) => {
        st.wrong += 1;
        st.streak = 0;
      });
      setFb({ id: Date.now(), ok: false, text: "−3s" });
      setShake((n) => n + 1);
      setQ(makeQ(q.level));
    }
    startedAt.current = Date.now();
  };

  useKeys((k) => {
    const i = Number(k) - 1;
    if (i >= 0 && i < 4) answer(q.options[i]);
  });

  return (
    <div className="mx-auto flex w-full max-w-xl flex-col items-center gap-5 no-select">
      <Hud score={s.score} left={left} total={TOTAL} streak={s.streak} label={`Level ${q.level}`} />
      <Feedback fb={fb} />
      <div
        key={shake}
        className={`flex h-40 w-full items-center justify-center rounded-3xl border border-white/10 bg-gradient-to-br from-violet-600/20 to-cyan-500/10 ${shake ? "anim-shake" : ""}`}
      >
        <div key={q.text + s.correct + s.wrong} className="anim-pop text-5xl font-black tracking-tight text-white sm:text-6xl">
          {q.text} <span className="text-slate-500">=</span> ?
        </div>
      </div>
      <div className="grid w-full grid-cols-2 gap-3">
        {q.options.map((o, i) => (
          <button
            key={`${q.text}-${o}`}
            onClick={() => answer(o)}
            className="group relative rounded-2xl border border-white/10 bg-white/5 py-5 text-3xl font-extrabold text-white transition hover:border-violet-400/60 hover:bg-violet-500/20 active:scale-95"
          >
            <span className="absolute left-3 top-2 text-[11px] font-semibold text-slate-500 group-hover:text-violet-300">{i + 1}</span>
            {o}
          </button>
        ))}
      </div>
      <p className="text-xs text-slate-500">Tip: use keys 1–4. Wrong answers cost 3 seconds.</p>
    </div>
  );
}
