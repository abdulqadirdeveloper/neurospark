import { useEffect, useMemo, useRef, useState } from "react";
import type { GameProps } from "../lib/types";
import { shuffle } from "../lib/hooks";
import { cn } from "../utils/cn";

const SIZE = 5;
const COUNT = SIZE * SIZE;

export default function Schulte({ onFinish }: GameProps) {
  const cells = useMemo(() => shuffle(Array.from({ length: COUNT }, (_, i) => i + 1)), []);
  const [next, setNext] = useState(1);
  const [wrongCell, setWrongCell] = useState<number | null>(null);
  const [mistakes, setMistakes] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const startedAt = useRef<number | null>(null);
  const done = useRef(false);

  useEffect(() => {
    const id = setInterval(() => {
      if (startedAt.current !== null && !done.current) setElapsed(Date.now() - startedAt.current);
    }, 50);
    return () => clearInterval(id);
  }, []);

  const tap = (n: number) => {
    if (done.current) return;
    if (startedAt.current === null) startedAt.current = Date.now();
    if (n === next) {
      if (n === COUNT) {
        done.current = true;
        const t = (Date.now() - startedAt.current) / 1000 + mistakes;
        setElapsed(t * 1000);
        onFinish({
          score: Math.max(0, Math.round((80 - t) * 3)),
          details: [
            { label: "Final time", value: `${t.toFixed(1)}s` },
            { label: "Mistakes", value: `${mistakes} (+${mistakes}s)` },
            { label: "Pace", value: `${(t / COUNT).toFixed(2)}s / number` },
          ],
        });
      }
      setNext(n + 1);
    } else {
      setMistakes((m) => m + 1);
      setWrongCell(n);
      setTimeout(() => setWrongCell(null), 250);
    }
  };

  const shown = (elapsed / 1000 + mistakes).toFixed(1);

  return (
    <div className="mx-auto flex w-full max-w-md flex-col items-center gap-5 no-select">
      <div className="flex w-full items-end justify-between">
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-widest text-slate-400">Find</div>
          <div className="text-4xl font-black tabular-nums text-cyan-300">{Math.min(next, COUNT)}</div>
        </div>
        <div className="text-center">
          <div className="text-[11px] font-semibold uppercase tracking-widest text-slate-400">Mistakes</div>
          <div className="text-2xl font-black tabular-nums text-white">{mistakes}</div>
        </div>
        <div className="text-right">
          <div className="text-[11px] font-semibold uppercase tracking-widest text-slate-400">Time</div>
          <div className="text-4xl font-black tabular-nums text-white">{startedAt.current === null ? "0.0" : shown}s</div>
        </div>
      </div>

      <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
        <div className="h-full rounded-full bg-gradient-to-r from-violet-500 to-cyan-400 transition-all" style={{ width: `${((next - 1) / COUNT) * 100}%` }} />
      </div>

      <div className="grid w-full grid-cols-5 gap-2 rounded-3xl border border-white/10 bg-black/30 p-3">
        {cells.map((n) => {
          const found = n < next;
          return (
            <button
              key={n}
              onClick={() => tap(n)}
              className={cn(
                "aspect-square rounded-xl border text-2xl font-black transition active:scale-90 sm:text-3xl",
                found
                  ? "border-emerald-500/20 bg-emerald-500/10 text-emerald-300/40"
                  : wrongCell === n
                    ? "anim-shake border-rose-400 bg-rose-500/30 text-white"
                    : "border-white/10 bg-white/5 text-white hover:border-cyan-400/60 hover:bg-cyan-400/10",
              )}
            >
              {n}
            </button>
          );
        })}
      </div>
      <p className="text-center text-xs text-slate-500">
        Tap 1 → 25 in order. Keep your eyes on the <b className="text-slate-300">centre</b> and use peripheral vision. Each mistake adds +1s.
      </p>
    </div>
  );
}
