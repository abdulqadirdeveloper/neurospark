import type { ComponentType } from "react";
import type { GameProps } from "../lib/types";
import SpeedMath from "./SpeedMath";
import Stroop from "./Stroop";
import NBack from "./NBack";
import PatternLogic from "./PatternLogic";
import Schulte from "./Schulte";
import SequenceMemory from "./SequenceMemory";

export type GameMeta = {
  id: string;
  name: string;
  emoji: string;
  skill: string;
  short: string;
  tagline: string;
  how: string[];
  why: string;
  duration: string;
  /** score considered "100%" for skill normalisation */
  ref: number;
  gradient: string;
  accent: string;
  Component: ComponentType<GameProps>;
};

export const GAMES: GameMeta[] = [
  {
    id: "math",
    name: "Speed Math",
    emoji: "➗",
    skill: "Processing speed",
    short: "Speed",
    tagline: "Mental arithmetic against the clock.",
    how: [
      "Solve the equation and tap the right answer (or press 1–4).",
      "Difficulty rises every 4 correct answers.",
      "Streaks multiply your points; wrong answers cost 3 seconds.",
    ],
    why: "Fast, accurate calculation trains processing speed and number sense — the skill with the strongest long-term evidence in the ACTIVE trial.",
    duration: "60 sec",
    ref: 380,
    gradient: "from-violet-500 to-indigo-600",
    accent: "text-violet-300",
    Component: SpeedMath,
  },
  {
    id: "stroop",
    name: "Stroop Clash",
    emoji: "🎨",
    skill: "Focus & flexibility",
    short: "Focus",
    tagline: "Ignore the word. Obey the rule. Switch fast.",
    how: [
      "A colour word is printed in a different ink colour.",
      "Follow the banner: tap the INK colour, or tap what the WORD says.",
      "The rule flips every 5 answers — adapt instantly.",
    ],
    why: "Suppressing the automatic response (reading) trains inhibitory control, and rule switching trains cognitive flexibility.",
    duration: "45 sec",
    ref: 420,
    gradient: "from-fuchsia-500 to-rose-500",
    accent: "text-fuchsia-300",
    Component: Stroop,
  },
  {
    id: "nback",
    name: "N-Back",
    emoji: "🧠",
    skill: "Working memory",
    short: "Memory",
    tagline: "Hold, update and compare — the classic mind gym.",
    how: [
      "A square lights up on a 3×3 grid every ~2 seconds.",
      "Press MATCH if it's in the same place as N steps ago.",
      "Pick N = 1, 2 or 3. A higher N means a higher score multiplier.",
    ],
    why: "N-back loads your working memory 'update' process, linked to reasoning and learning. Most reliable gains are in memory tasks themselves.",
    duration: "~50 sec",
    ref: 200,
    gradient: "from-cyan-400 to-blue-600",
    accent: "text-cyan-300",
    Component: NBack,
  },
  {
    id: "pattern",
    name: "Pattern Logic",
    emoji: "🧩",
    skill: "Fluid reasoning",
    short: "Logic",
    tagline: "Crack the rule. Predict what comes next.",
    how: [
      "Study the number or letter series and find the hidden rule.",
      "Choose the item that completes it.",
      "Rules get trickier: growth, alternation, Fibonacci, interleaving…",
    ],
    why: "Inductive reasoning on novel patterns is the heart of fluid intelligence — the type of thinking IQ tests measure.",
    duration: "90 sec",
    ref: 230,
    gradient: "from-emerald-400 to-teal-600",
    accent: "text-emerald-300",
    Component: PatternLogic,
  },
  {
    id: "schulte",
    name: "Schulte Table",
    emoji: "👁️",
    skill: "Visual attention",
    short: "Vision",
    tagline: "Find 1 → 25 as fast as you can.",
    how: [
      "Numbers 1–25 are scattered on a grid.",
      "Tap them in ascending order — the clock starts on your first tap.",
      "Each mistake adds 1 second. Fix your gaze on the centre cell.",
    ],
    why: "A classic speed-reading & attention drill. It trains visual search and widens your peripheral vision.",
    duration: "~30 sec",
    ref: 180,
    gradient: "from-amber-400 to-orange-600",
    accent: "text-amber-300",
    Component: Schulte,
  },
  {
    id: "sequence",
    name: "Sequence Memory",
    emoji: "✨",
    skill: "Short-term memory",
    short: "Recall",
    tagline: "Watch the flashes. Repeat the pattern.",
    how: [
      "Squares flash one after another — remember the order.",
      "Repeat the sequence by tapping the same squares.",
      "Each round adds one more step. You have 2 lives.",
    ],
    why: "Stretching your memory span builds visuospatial working memory and focused concentration.",
    duration: "1–2 min",
    ref: 200,
    gradient: "from-pink-500 to-purple-600",
    accent: "text-pink-300",
    Component: SequenceMemory,
  },
];

export const getGame = (id: string) => GAMES.find((g) => g.id === id)!;
