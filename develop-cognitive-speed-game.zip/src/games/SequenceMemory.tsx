import { useEffect, useRef, useState } from "react";
import type { GameProps } from "../lib/types";
import { rand } from "../lib/hooks";
import { cn } from "../utils/cn";

const STEP = 700;
const FLASH = 480;

function makeSeq(len: number) {
  const seq: number[] = [];
  for (let i = 0; i < len; i++) {
    let c = rand(0, 8);
    while (i > 0 && c === seq[i - 1]) c = rand(0, 8);
    seq.push(c);
  }
  return seq;
}

export default function SequenceMemory({ onFinish }: GameProps) {
  const [len, setLen] = useState(2);
  const [seq, setSeq] = useState<number[]>(() => makeSeq(2));
  const [phase, setPhase] = useState<"show" | "input" | "between">("show");
  const [lit, setLit] = useState<number | null>(null);
  const [pressed, setPressed] = useState<{ cell: number; ok: boolean } | null>(null);
  const [pos, setPos] = useState(0);
  const [lives, setLives] = useState(2);
  const [score, setScore] = useState(0);
  const [msg, setMsg] = useState("Watch the pattern…");
  const best = useRef(1);
  const timers = useRef<number[]>([]);
  const finished = useRef(false);

  const later = (fn: () => void, ms: number) => {
    timers.current.push(window.setTimeout(fn, ms));
  };

  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  // play the sequence
  useEffect(() => {
    if (phase !== "show") return;
    setMsg("Watch the pattern…");
    setPos(0);
    const ts: number[] = [];
    seq.forEach((c, i) => {
      ts.push(window.setTimeout(() => setLit(c), 600 + i * STEP));
      ts.push(window.setTimeout(() => setLit(null), 600 + i * STEP + FLASH));
    });
    ts.push(
      window.setTimeout(() => {
        setPhase("input");
        setMsg("Your turn — repeat it!");
      }, 600 + seq.length * STEP),
    );
    return () => ts.forEach(clearTimeout);
  }, [phase, seq]);

  const finish = (finalScore: number) => {
    if (finished.current) return;
    finished.current = true;
    onFinish({
      score: finalScore,
      details: [
        { label: "Longest sequence", value: String(best.current) },
        { label: "Rounds cleared", value: String(Math.max(0, best.current - 1)) },
        { label: "Final score", value: String(finalScore) },
      ],
    });
  };

  const tap = (cell: number) => {
    if (phase !== "input") return;
    const ok = seq[pos] === cell;
    setPressed({ cell, ok });
    later(() => setPressed(null), 220);
    if (!ok) {
      setPhase("between");
      const remaining = lives - 1;
      setLives(remaining);
      setMsg(remaining > 0 ? "Oops! Try a fresh sequence of the same length." : "Out of lives!");
      later(() => {
        if (remaining <= 0) finish(score);
        else {
          setSeq(makeSeq(len));
          setPhase("show");
        }
      }, 1100);
      return;
    }
    const np = pos + 1;
    setPos(np);
    if (np === seq.length) {
      const ns = score + seq.length * 5;
      setScore(ns);
      best.current = Math.max(best.current, seq.length);
      setPhase("between");
      setMsg(`Perfect! +${seq.length * 5}`);
      later(() => {
        setLen(len + 1);
        setSeq(makeSeq(len + 1));
        setPhase("show");
      }, 800);
    }
  };

  return (
    <div className="mx-auto flex w-full max-w-md flex-col items-center gap-5 no-select">
      <div className="flex w-full items-end justify-between">
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-widest text-slate-400">Score</div>
          <div className="text-3xl font-black tabular-nums text-white">{score}</div>
        </div>
        <div className="text-center">
          <div className="text-[11px] font-semibold uppercase tracking-widest text-slate-400">Lives</div>
          <div className="text-2xl">{"❤️".repeat(lives)}{"🖤".repeat(Math.max(0, 2 - lives))}</div>
        </div>
        <div className="text-right">
          <div className="text-[11px] font-semibold uppercase tracking-widest text-slate-400">Length</div>
          <div className="text-3xl font-black tabular-nums text-white">{len}</div>
        </div>
      </div>

      <div className={cn("w-full rounded-xl py-2 text-center text-sm font-bold", phase === "input" ? "bg-cyan-400/10 text-cyan-300" : "bg-white/5 text-slate-300")}>
        {msg}
      </div>

      <div className="grid w-full grid-cols-3 gap-3 rounded-3xl border border-white/10 bg-black/30 p-4">
        {Array.from({ length: 9 }, (_, i) => {
          const on = lit === i;
          const p = pressed?.cell === i ? pressed : null;
          return (
            <button
              key={i}
              disabled={phase !== "input"}
              onClick={() => tap(i)}
              className={cn(
                "aspect-square rounded-2xl border transition-all duration-150",
                on && "scale-100 border-fuchsia-300 bg-gradient-to-br from-fuchsia-400 to-violet-500 shadow-[0_0_30px_rgba(217,70,239,0.6)]",
                !on && !p && "scale-95 border-white/5 bg-white/5",
                !on && !p && phase === "input" && "hover:bg-white/10",
                p?.ok && "scale-100 border-emerald-300 bg-emerald-500/50",
                p && !p.ok && "anim-shake border-rose-300 bg-rose-500/60",
              )}
            />
          );
        })}
      </div>
      <p className="text-xs text-slate-500">Each cleared round scores 5 × the sequence length. Two mistakes and it's over.</p>
    </div>
  );
}
